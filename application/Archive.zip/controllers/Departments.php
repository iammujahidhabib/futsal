<?php
ob_start();
defined('BASEPATH') or exit('No direct script access allowed');

class Departments extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_templates');
        $this->session->set_userdata('func', 'departments');
        if ($this->session->isLogedIn == false) {
            redirect('login');
        }
        $this->session->set_userdata('tree', 'master');
    }
    public function index()
    {
        $data['departments'] = $this->M_templates->view('departments')->result();
        $this->load->view('departments/index', $data);
    }
    public function create()
    {
        if ($this->input->post()) {
            $data = [
                'department' => $this->input->post('department'),
            ];
            $this->M_templates->insert('departments', $data);
            redirect('departments');
        } else {
            $this->load->view('departments/create');
        }
    }
    public function edit($id)
    {
        $where = ['id_department' => $id];
        if ($this->input->post()) {
            $data = [
                'department' => $this->input->post('department'),
            ];
            $this->M_templates->update('departments', $where, $data);
            redirect('departments');
        } else {
            $data['departments'] = $this->M_templates->view_where('departments', $where)->row();
            $this->load->view('departments/edit', $data);
        }
    }
    public function delete($id)
    {
        $where = ['id_department' => $id];
        $this->M_templates->delete('departments', $where);
        redirect('departments');
    }
}
