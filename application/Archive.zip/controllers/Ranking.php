<?php
ob_start();
defined('BASEPATH') or exit('No direct script access allowed');

class Ranking extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_templates');
        $this->load->model('Rankings');
        if ($this->session->isLogedIn == false) {
            redirect('login');
        }
        $this->session->set_userdata('tree', 'ranking');
    }
    public function employee()
    {
        $this->session->set_userdata('func', 'rankemployee');
        $data['data'] = $this->Rankings->process_employee();
        // $data['sub_data'] = $this->M_templates->sub_monthly_employee()->result_array();
        // $data['chart_data'] = $this->M_templates->chart_monthly_employee();
        // if ($this->session->role == 1) {
        //     $where_employee = [
        //         'role >' => $this->session->role
        //     ];
        // } elseif ($this->session->role <= 2) {
        //     $where_employee = [
        //         'discipline' => $this->session->discipline,
        //         'role >' => $this->session->role
        //     ];
        // } else {
        //     $where_employee = [
        //         'id_employee' => $this->session->id,
        //     ];
        // }
        // $data['employees'] = $this->M_templates->view_where("employees", $where_employee)->result();
        // echo "<pre>";
        // print_r($data['data']);
        $this->load->view('ranking/employee', $data);
    }
    public function discipline()
    {
        $this->session->set_userdata('func', 'rankdiscipline');
        $data['data'] = $this->Rankings->process_discipline();
        // $data['sub_data'] = $this->M_templates->sub_monthly_employee()->result_array();
        // $data['chart_data'] = $this->M_templates->chart_monthly_employee();
        // if ($this->session->role == 1) {
        //     $where_employee = [
        //         'role >' => $this->session->role
        //     ];
        // } elseif ($this->session->role <= 2) {
        //     $where_employee = [
        //         'discipline' => $this->session->discipline,
        //         'role >' => $this->session->role
        //     ];
        // } else {
        //     $where_employee = [
        //         'id_employee' => $this->session->id,
        //     ];
        // }
        // $data['employees'] = $this->M_templates->view_where("employees", $where_employee)->result();
        // echo "<pre>";
        // print_r($data['data']);
        $this->load->view('ranking/discipline', $data);
    }
}
