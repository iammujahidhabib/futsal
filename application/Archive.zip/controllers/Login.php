<?php
ob_start();
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_templates');
	}
	public function index()
	{
		$this->load->view('login/login');
	}
	public function check()
	{
		$login = $this->M_templates->view_where(
			'view_employees',
			array(
				'username' => $this->input->post('username'),
				'password' => md5($this->input->post('password'))
			)
		)->result();
		// echo md5($this->input->post('password'))."<br>";
		// print_r($login);
		if (count($login) == 1) {
			$session = array(
				'id'				=> $login[0]->id_employee,
				'username'			=> $login[0]->username,
				'name'				=> $login[0]->name,
				'role'				=> $login[0]->role,
				'role_name'			=> $login[0]->role_name,
				'discipline'		=> $login[0]->discipline,
				'discipline_name'	=> $login[0]->discipline_name,
				'department'		=> $login[0]->department,
				'department_name'	=> $login[0]->department_name,
				'isLogedIn'			=> TRUE
			);
			$this->session->set_userdata($session);
			redirect('dashboard');
		} else {
			$this->session->set_flashdata('error_log', '<div class="alert alert-danger" role="alert">Username atau Password salah! </div>');
			redirect('login');
		}
	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('login');
	}
}
