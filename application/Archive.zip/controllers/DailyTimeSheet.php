<?php
ob_start();
defined('BASEPATH') or exit('No direct script access allowed');

class DailyTimeSheet extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_templates');
        if ($this->session->isLogedIn == false) {
            redirect('login');
        }
        $this->session->set_userdata('tree', 'time_sheets');
    }
    public function index()
    {
        $this->load->view('dailytimesheet/index');
    }
    public function create()
    {
        $this->session->set_userdata('func', 'dailytimesheetcreate');
        $sess_id = $this->session->id;
        $date = date('Y-m-d');
        $where = ['id_employee' => $sess_id, 'date' => $date];
        $checking = $this->M_templates->view_where('view_time_sheet_jobs', $where)->result();
        if ($this->input->post()) {
            $job_number = $this->input->post('job_number[]');
            $detail_pekerjaan = $this->input->post('detail_pekerjaan');
            $man_hour = $this->input->post('man_hour');
            $type = $this->input->post('type');
            for ($i = 0; $i < count($this->input->post('job_number')); $i++) {
                $data = [
                    'id_employee' => $sess_id,
                    'id_job' => $job_number[$i],
                    // 'job_title' => $this->input->post('job_title')[$i],
                    'subordinated' => $type[$i],
                    'hour' => $man_hour[$i],
                    'detail_job' => $detail_pekerjaan[$i],
                    'date' => $this->input->post('date'),
                ];
                print_r($data);
                $this->M_templates->insert('time_sheets', $data);
            }
            $this->session->set_flashdata("message", '<div class="alert alert-success" role="alert">
                    Daily Employee Job Time Sheet berhasil ditambahkan!
                </div>');
            redirect('dailytimesheet/create');
        } else {
            if (count($checking) > 0) {
                $data['hour_per_month'] = $this->M_templates->total_hour_per_month();
                $data['day_per_month'] = $this->M_templates->total_day_per_month();
                $data['jobs'] = $this->M_templates->view('jobs')->result();
                $data['time_sheets'] = $checking;
                $this->load->view('dailytimesheet/update', $data);
            } else {
                $data['jobs'] = $this->M_templates->view('jobs')->result();
                $this->load->view('dailytimesheet/create', $data);
            }
        }
    }
    public function update()
    {
        $this->session->set_userdata('func', 'dailytimesheetcreate');
        $sess_id = $this->session->id;
        $date = date('Y-m-d');
        $where = ['id_employee' => $sess_id, 'date' => $date];
        if ($this->input->post()) {
            $job_number = $this->input->post('job_number[]');
            $detail_pekerjaan = $this->input->post('detail_pekerjaan');
            $man_hour = $this->input->post('man_hour');
            $type = $this->input->post('type');
            $id = $this->input->post('id');
            for ($i = 0; $i < count($this->input->post('job_number')); $i++) {
                $data = [
                    'id_employee' => $sess_id,
                    'id_job' => $job_number[$i],
                    // 'job_title' => $this->input->post('job_title')[$i],
                    'subordinated' => $type[$i],
                    'hour' => $man_hour[$i],
                    'detail_job' => $detail_pekerjaan[$i],
                    'date' => $this->input->post('date'),
                ];
                if ($id[$i] == "-") {
                    $this->M_templates->insert('time_sheets', $data);
                } else {
                    $this->M_templates->update('time_sheets', ['id_time_sheet' => $id[$i]], $data);
                }
                print_r($data);
            }
            $this->session->set_flashdata("message", '<div class="alert alert-success" role="alert">
                    Daily Employee Job Time Sheet berhasil ditambahkan!
                </div>');
            redirect('dailytimesheet/create');
        }
    }
    public function review()
    {
        if ($this->session->role <= 2) {
            if ($this->session->role == 1) {
                $where_employee = [
                    'role >' => $this->session->role
                ];
            } elseif ($this->session->role <= 2) {
                $where_employee = [
                    'discipline' => $this->session->discipline,
                    'role >' => $this->session->role
                ];
            }
            $data['employees'] = $this->M_templates->view_where("employees", $where_employee)->result();
            if (isset($_GET['employee'])) {
                $where = [
                    'id_employee' => $_GET['employee'],
                    'date' => $_GET['date']
                ];
                $data['is_self'] = 'n';
                $data['status_approve'] = $this->M_templates->status_approve($_GET['employee'], $_GET['date']);
                $data['this_employee_id'] = $_GET['employee'];
                $data['this_date'] = $_GET['date'];
            } else {
                $where = [
                    'id_employee' => $this->session->id,
                    'date' => date('Y-m-d')
                ];
                $data['is_self'] = 'y';
                $data['status_approve'] = $this->M_templates->status_approve($this->session->id, date('Y-m-d'));
                $data['this_employee_id'] = $this->session->id;
                $data['this_date'] = date('Y-m-d');
            }
        } else {
            $where = [
                'id_employee' => $this->session->id,
                'date' => date('Y-m-d')
            ];
            $data['status_approve'] = $this->M_templates->status_approve($this->session->id, date('Y-m-d'));
            $data['this_employee_id'] = $this->session->id;
            $data['this_date'] = date('Y-m-d');
        }
        // echo $data['is_self'];
        $data['time_sheets'] = $this->M_templates->view_where("view_time_sheet_jobs", $where)->result();
        $data['hour_per_month'] = $this->M_templates->total_hour_per_month();
        $data['day_per_month'] = $this->M_templates->total_day_per_month();
        // echo "<pre>";
        // print_r($data['employees']);
        // echo $day_per_month;
        $this->session->set_userdata('func', 'dailytimesheetreview');
        $this->load->view('dailytimesheet/review', $data);
    }
    public function initSelect2()
    {
        $request = 1;
        if (isset($_POST['request'])) {
            $request = $_POST['request'];
        }

        // Select2 data
        if ($request == 1) {
            if (!isset($_POST['searchTerm'])) {
                $fetchData = $this->M_templates->query("select id_job AS id,job_number AS text from jobs order by job_number limit 5")->result_array();
            } else {
                $search = $_POST['searchTerm'];
                $fetchData = $this->M_templates->query("select id_job AS id,job_number AS text from jobs where job_number like '%" . $search . "%' limit 5")->result_array();
            }
            echo json_encode($fetchData);
            exit;
        }
        if ($request == 2) {
            $html = '<tr id="tr_sub_job">
                        <td></td>
                        <td id="td_select_job_number">
                            <select aria-placeholder="type job number" name="job_number[]" class="form-control js-example-basic-single">
                                <option value="" selected disabled></option>
                            </select>
                        </td>
                        <td>
                            <input type="text" name="job_title[]" id="job_title" class="form-control">
                        </td>
                        <td>
                            <select name="type" id="type" class="form-control">
                                <option value="MEMBER">MEMBER</option>
                                <option value="COORDINATOR">COORDINATOR</option>
                            </select>
                        </td>
                        <td>
                            <input type="number" name="man_hour" id="man_hour" class="form-control">
                        </td>
                        <td colspan="2">
                            <textarea name="detail_pekerjaan" id="detail_pekerjaan" rows="3" class="form-control"></textarea>
                        </td>
                        <td>
                            <button class="btn btn-default btn-sm" id="add_sub_job">add sub-job</button><br>
                            <button class="btn btn-default btn-sm" id="remove_sub_job">remove sub-job</button>
                        </td>
                    </tr>';
            echo $html;
            exit;
        }
    }
    public function getJobTitle($id)
    {
        $where = ['id_job' => $id];
        $data = $this->M_templates->view_where('jobs', $where)->row();
        echo json_encode($data->job_title);
    }
    public function delete()
    {
        $where = ['id_time_sheet' => $_GET['id']];
        $delete = $this->M_templates->delete("time_sheets", $where);
        if ($delete) {
            echo json_encode(['message' => "success"]);
        } else {
            echo json_encode(['message' => "error"]);
        }
    }
    public function approve($id, $status, $date)
    {
        $where = ['id_employee' => $id, 'date' => $date];
        $checking = $this->M_templates->view_where('view_time_sheet_jobs', $where)->result();
        if ($status == 1) {
            foreach ($checking as $key) {
                $data_approve = [
                    'approve_status' => 1,
                    'approve_by' => $this->session->id,
                    'approve_date' => date('Y-m-d')
                ];
                $this->M_templates->update("time_sheets", ['id_time_sheet' => $key->id_time_sheet], $data_approve);
            }
            $this->session->set_flashdata("message", '<div class="alert alert-success" role="alert">
                        Daily Employee Job Time Sheet berhasil diapprove!
                    </div>');
        }
        redirect("dailytimesheet/review?employee=$id&date=$date");
    }
}
