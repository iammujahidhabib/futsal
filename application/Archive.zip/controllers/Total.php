<?php
ob_start();
defined('BASEPATH') or exit('No direct script access allowed');

class Total extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_templates');
        $this->load->model('Totals');
        if ($this->session->isLogedIn == false) {
            redirect('login');
        }
        $this->session->set_userdata('tree', 'totals_');
    }
    public function index()
    {
        $this->session->set_userdata('func', 'total_');
        $data['data'] = $this->Totals->get_per_job()->result_array();
        $data['sub_data'] = $this->Totals->get_sub_per_job()->result_array();
        $data['jobs'] = $this->M_templates->view("jobs")->result();
        // echo "<pre>";
        // print_r($data['sub_data']);
        $this->load->view('total/index', $data);
    }
    public function get_job($id)
    {
        $data = $this->M_templates->view_where('jobs',['id_job'=>$id])->row();
        echo json_encode($data);
    }
}
