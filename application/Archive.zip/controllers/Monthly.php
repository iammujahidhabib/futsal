<?php
ob_start();
defined('BASEPATH') or exit('No direct script access allowed');

class Monthly extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_templates');
        if ($this->session->isLogedIn == false) {
            redirect('login');
        }
        $this->session->set_userdata('tree', 'monthly');
    }
    public function employee()
    {
        $this->session->set_userdata('func', 'monthlyemployee');
        $data['data'] = $this->M_templates->monthly_employee()->result_array();
        $data['sub_data'] = $this->M_templates->sub_monthly_employee()->result_array();
        $data['chart_data'] = $this->M_templates->chart_monthly_employee();
        if ($this->session->role == 1) {
            $where_employee = [
                'role >' => $this->session->role
            ];
        } elseif ($this->session->role <= 2) {
            $where_employee = [
                'discipline' => $this->session->discipline,
                'role >' => $this->session->role
            ];
        }else{
            $where_employee = [
                'id_employee' => $this->session->id,
            ];
        }
        $data['employees'] = $this->M_templates->view_where("employees", $where_employee)->result();
        // echo "<pre>";
        // print_r($data['chart_data']);
        $this->load->view('monthly/employee', $data);
    }
    public function discipline()
    {

        $this->session->set_userdata('func', 'monthlydiscipline');
        $data['data'] = $this->M_templates->monthly_discipline()->result_array();
        $data['sub_data'] = $this->M_templates->sub_monthly_discipline()->result_array();
        $data['chart_data'] = $this->M_templates->chart_monthly_discipline();
        if ($this->session->role == 1 || $this->session->role == 2) {
            $data['disciplines'] = $this->M_templates->view("disciplines")->result();
        } else {
            $where_discipline = [
                'id_discipline' => $this->session->discipline,
            ];
            $data['disciplines'] = $this->M_templates->view_where("disciplines", $where_discipline)->result();
        }
        // echo "<pre>";
        // print_r($data['chart_data']);
        $this->load->view('monthly/discipline', $data);
    }
    public function department()
    {

        $this->session->set_userdata('func', 'monthlydepartment');
        $data['data'] = $this->M_templates->monthly_department()->result_array();
        if ($this->session->role == 1 || $this->session->role == 2) {
            $data['departments'] = $this->M_templates->view("departments")->result();
        } else {
            $where_department = [
                'id_department' => $this->session->department,
            ];
            $data['departments'] = $this->M_templates->view_where("departments", $where_department)->result();
        }
        $data['sub_data'] = $this->M_templates->sub_monthly_department()->result_array();
        $data['chart_data'] = $this->M_templates->chart_monthly_department();
        // $data['departments'] = $this->M_templates->view("departments")->result();
        // echo "<pre>";
        // print_r($data['chart_data']);
        $this->load->view('monthly/department', $data);
    }
    public function perjob()
    {

        $this->session->set_userdata('func', 'monthlyperjob');
        $data['data'] = $this->M_templates->monthly_perjob()->result_array();
        $data['sub_data'] = $this->M_templates->sub_monthly_perjob()->result_array();
        // if ($this->session->role == 1) {
        //     $where_employee = [
        //         'role >' => $this->session->role
        //     ];
        // } elseif ($this->session->role <= 2) {
        //     $where_employee = [
        //         'discipline' => $this->session->discipline,
        //         'role >' => $this->session->role
        //     ];
        // }
        $data['chart_data'] = $this->M_templates->chart_monthly_perjob();
        $data['chart2_data'] = $this->M_templates->chart2_monthly_perjob();
        $data['jobs'] = $this->M_templates->view("jobs")->result();
        // echo "<pre>";
        // print_r($data['chart_data']);
        $this->load->view('monthly/perjob', $data);
    }
}
