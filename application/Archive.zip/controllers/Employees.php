<?php
ob_start();
defined('BASEPATH') or exit('No direct script access allowed');

class Employees extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_templates');
        $this->session->set_userdata('func', 'employees');
        if ($this->session->isLogedIn == false) {
            redirect('login');
        }
        $this->session->set_userdata('tree', 'master');
    }
    public function index()
    {
        $data['employees'] = $this->M_templates->view('view_employees')->result();
        $this->load->view('employees/index', $data);
    }
    public function create()
    {
        if ($this->input->post()) {
            $data = [
                'name' => $this->input->post('name'),
                'badge' => $this->input->post('badge'),
                'discipline' => $this->input->post('discipline'),
                'username' => $this->input->post('username'),
                'email' => $this->input->post('email'),
                'password' => md5($this->input->post('password')),
                'role' => $this->input->post('role'),
            ];
            $this->M_templates->insert('employees', $data);
            redirect('employees');
        } else {
            $data['role'] = [
                ['id' => 1, "name" => "Manager RBP"],
                ['id' => 2, "name" => "Superintendent RMP"],
                ['id' => 3, "name" => "Engineer Senior / Superintendent"],
                ['id' => 4, "name" => "Engineer / Staff"],
            ];
            $data['disciplines'] = $this->M_templates->view('disciplines')->result();
            // print_r($data['disciplines']);
            $this->load->view('employees/create', $data);
        }
    }
    public function edit($id)
    {
        $where = ['id_employee' => $id];
        if ($this->input->post()) {
            $data = [
                'name' => $this->input->post('name'),
                'badge' => $this->input->post('badge'),
                'discipline' => $this->input->post('discipline'),
                'username' => $this->input->post('username'),
                'email' => $this->input->post('email'),
                'password' => md5($this->input->post('password')),
                'role' => $this->input->post('role'),
            ];
            if ($this->input->post('password')) {
                $data['password'] = md5($this->input->post('password'));
            }
            $this->M_templates->update('employees', $where, $data);
            redirect('employees');
        } else {
            $data['employees'] = $this->M_templates->view('employees')->row();
            $data['role'] = [
                ['id' => 1, "name" => "Manager RBP"],
                ['id' => 2, "name" => "Superintendent RMP"],
                ['id' => 3, "name" => "Engineer Senior / Superintendent"],
                ['id' => 4, "name" => "Engineer / Staff "],
            ];
            $data['disciplines'] = $this->M_templates->view('disciplines')->result();
            // print_r($data['disciplines']);
            $this->load->view('employees/edit', $data);
        }
    }
    public function delete($id)
    {
        $where = ['id_employee' => $id];
        $this->M_templates->delete('employees', $where);
        redirect('employees');
    }
}
