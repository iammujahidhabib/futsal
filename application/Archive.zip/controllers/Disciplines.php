<?php
ob_start();
defined('BASEPATH') or exit('No direct script access allowed');

class Disciplines extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_templates');
        $this->session->set_userdata('func', 'disciplines');
        if ($this->session->isLogedIn == false) {
            redirect('login');
        }
        $this->session->set_userdata('tree', 'master');
    }
    public function index()
    {
        $data['disciplines'] = $this->M_templates->view('disciplines')->result();
        $this->load->view('disciplines/index',$data);
    }
    public function create()
    {
        if ($this->input->post()) {
            $data = [
                'discipline' => $this->input->post('discipline'),
            ];
            $this->M_templates->insert('disciplines', $data);
            redirect('disciplines');
        } else {
            $this->load->view('disciplines/create');
        }
    }
    public function edit($id)
    {
        $where = ['id_discipline' => $id];
        if ($this->input->post()) {
            $data = [
                'discipline' => $this->input->post('discipline'),
            ];
            $this->M_templates->update('disciplines', $where, $data);
            redirect('disciplines');
        } else {
            $data['disciplines'] = $this->M_templates->view_where('disciplines', $where)->row();
            $this->load->view('disciplines/edit', $data);
        }
    }
    public function delete($id)
    {
        $where = ['id_discipline' => $id];
        $this->M_templates->delete('disciplines', $where);
        redirect('disciplines');
    }
}
