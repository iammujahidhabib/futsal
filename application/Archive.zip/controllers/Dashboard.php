<?php
ob_start();
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_templates');
        $this->session->set_userdata('func','dash');
        if ($this->session->isLogedIn == false) {
            redirect('login');
        }
    }
    public function index()
    {
        $this->load->view('dashboard/index');
    }
}