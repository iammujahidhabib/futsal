<?php
ob_start();
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_admin');
		if ($this->session->isLogin == FALSE) {
			redirect('login');
		}
	}
	public function index()
	{
		$session = ['func' => 'dash', 'wrap' => 'Proyek Pernikahan'];
		$this->session->set_userdata($session);
		$data['bulanan']= $this->M_admin->query('SELECT SUM(total_harga) AS total,COUNT(id_transaksi) AS pesanan FROM `transaksi` WHERE date LIKE "'.date("Y-m").'%"')->result();
		$data['tahunan']= $this->M_admin->query('SELECT DATE_FORMAT(date,"%Y-%m") AS bulan, SUM(total_harga) AS total,COUNT(id_transaksi) AS pesanan FROM `transaksi` WHERE date LIKE "'.date("Y").'%" GROUP BY DATE_FORMAT(date,"%Y-%m")')->result();
		$data['proyek'] = $this->M_admin->project_on_going()->result();
		$data['proyek_on_duty'] = $this->M_admin->project_on_duty()->result();
		$this->load->view('index', $data);
	}
	public function orders()
	{
		$session = ['func' => 'orders', 'wrap' => 'Data Pesanan'];
		$this->session->set_userdata($session);
		$data['keranjang'] = $this->M_admin->query("SELECT paket.paket,transaksi.tanggal_acara,transaksi.id_transaksi,transaksi.total_harga,transaksi.date,transaksi.keterangan_transaksi,paket.deskripsi_paket,paket.id_paket,transaksi.status_transaksi,transaksi.keterangan_wo FROM transaksi JOIN paket USING(id_paket) ORDER BY transaksi.date DESC")->result();
		// $data['keranjang'] = $this->M_admin->join('transaksi', 'paket.id_paket=transaksi.id_paket', 'paket',)->result();
		$this->load->view('order/order', $data);
	}
	public function paket()
	{
		$session = ['func' => 'paket', 'wrap' => 'Paket Pernikahan'];
		$this->session->set_userdata($session);

		$data['paket'] = $this->M_admin->view('paket')->result();
		$this->load->view('paket', $data);
	}
	public function dekorasi()
	{
		$session = ['func' => 'dekorasi', 'wrap' => 'Dekorasi Pernikahan'];
		$this->session->set_userdata($session);

		$data['dekorasi'] = $this->M_admin->view('dekorasi')->result();
		$this->load->view('dekorasi', $data);
	}
	public function hiburan()
	{
		$session = ['func' => 'hiburan', 'wrap' => 'Hiburan Wedding'];
		$this->session->set_userdata($session);

		$data['hiburan'] = $this->M_admin->view('hiburan')->result();
		$this->load->view('hiburan', $data);
	}
	public function photography()
	{
		$session = ['func' => 'photography', 'wrap' => 'Dokumentasi Wedding'];
		$this->session->set_userdata($session);

		$data['photography'] = $this->M_admin->view('photography')->result();
		$this->load->view('photography', $data);
	}
	public function katering()
	{
		$session = ['func' => 'katering', 'wrap' => 'Katering Wedding'];
		$this->session->set_userdata($session);

		$data['katering'] = $this->M_admin->view('katering')->result();
		$this->load->view('katering', $data);
	}
	public function rias()
	{
		$session = ['func' => 'rias', 'wrap' => 'Rias Wedding'];
		$this->session->set_userdata($session);

		$data['rias'] = $this->M_admin->view('rias')->result();
		$this->load->view('rias', $data);
	}
	public function galeri()
	{
		$session = ['func' => 'galeri', 'wrap' => 'Album Foto Pernikahan'];
		$this->session->set_userdata($session);
		$data['galeri'] = $this->M_admin->view('albums')->result();

		$this->load->view('album', $data);
	}
	public function customer()
	{
		$session = ['func' => 'customer', 'wrap' => 'Customer Wedding'];
		$this->session->set_userdata($session);
		$data['customer'] = $this->M_admin->join_where('members', 'users.id_member = members.id_member', 'users', ['role' => 3])->result();

		$this->load->view('customer', $data);
	}
	public function ubah_stat($stat, $id)
	{
		$this->M_admin->update('users', ['id_user' => $id], ['status' => $stat]);
		redirect('admin/customer');
	}
	public function profile()
	{
		$session = ['func' => 'dash', 'wrap' => 'Profil Saya'];
		$this->session->set_userdata($session);
		$data['customer'] = $this->M_admin->join_where('users', 'users.id_admin = admin.id_admin', 'admin', ['users.role' => 1, 'users.id_admin' => $this->session->id])->result();

		$this->load->view('profile', $data);
	}
	public function update_pass()
	{
		$lama = $this->M_admin->view_where('admin', [
			'id_admin' => $this->session->id,
			'password' => md5($this->input->post('password_lama'))
		])->result();
		// print_r($lama);
		// echo $this->input->post('password_lama');
		// echo $this->input->post('password');
		if (!empty($lama)) {
			$this->M_admin->update(
				'admin',
				[
					'id_admin' => $this->session->id,
					'password' => md5($this->input->post('password_lama'))
				],
				['password' => md5($this->input->post('password'))]
			);
			$this->session->set_flashdata('success', '<div class="alert alert-success">Password berhasil diubah</div>');
			redirect('admin/profile');
		} else {
			$this->session->set_flashdata('success', '<div class="alert alert-danger">Password gagal diubah</div>');
			redirect('admin/profile');
		}
	}
}
