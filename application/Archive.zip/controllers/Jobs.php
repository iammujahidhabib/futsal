<?php
ob_start();
defined('BASEPATH') or exit('No direct script access allowed');

class Jobs extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_templates');
        $this->session->set_userdata('func', 'jobs');
        if ($this->session->isLogedIn == false) {
            redirect('login');
        }
        $this->session->set_userdata('tree', 'master');
    }
    public function index()
    {
        $data['jobs'] = $this->M_templates->view('jobs')->result();
        $this->load->view('jobs/index',$data);
    }
    public function create()
    {
        if ($this->input->post()) {
            $data = [
                'job_number' => $this->input->post('job_number'),
                'job_title' => $this->input->post('job_title'),
            ];
            $this->M_templates->insert('jobs', $data);
            redirect('jobs');
        } else {
            $this->load->view('jobs/create');
        }
    }
    public function edit($id)
    {
        $where = ['id_job' => $id];
        if ($this->input->post()) {
            $data = [
                'job_number' => $this->input->post('job_number'),
                'job_title' => $this->input->post('job_title'),
            ];
            $this->M_templates->update('jobs', $where, $data);
            redirect('jobs');
        } else {
            $data['jobs'] = $this->M_templates->view_where('jobs', $where)->row();
            $this->load->view('jobs/edit', $data);
        }
    }
    public function delete($id)
    {
        $where = ['id_job' => $id];
        $this->M_templates->delete('jobs', $where);
        redirect('jobs');
    }
}
