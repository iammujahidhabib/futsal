<?php
ob_start();
defined('BASEPATH') or exit('No direct script access allowed');

class Resume extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_templates');
        $this->load->model('Resumes');
        if ($this->session->isLogedIn == false) {
            redirect('login');
        }
        $this->session->set_userdata('tree', 'resume');
    }
    public function index()
    {
        $data['data'] = $this->Resumes->get_employee()->result_array();
        $data['sub_data'] = $this->Resumes->get_sub_employee()->result_array();
        $this->session->set_userdata('func', 'resumes');
        if ($this->session->role == 1) {
            $where_employee = [
                'role >' => $this->session->role
            ];
        } elseif ($this->session->role <= 2) {
            $where_employee = [
                'discipline' => $this->session->discipline,
                'role >' => $this->session->role
            ];
        } else {
            $where_employee = [
                'id_employee' => $this->session->id,
            ];
        }
        if ($this->session->role == 1 || $this->session->role == 2) {
            $data['disciplines'] = $this->M_templates->view("disciplines")->result();
        } else {
            $where_discipline = [
                'id_discipline' => $this->session->discipline,
            ];
            $data['disciplines'] = $this->M_templates->view_where("disciplines", $where_discipline)->result();
        }
        if ($this->session->role == 1 || $this->session->role == 2) {
            $data['departments'] = $this->M_templates->view("departments")->result();
        } else {
            $where_department = [
                'id_department' => $this->session->department,
            ];
            $data['departments'] = $this->M_templates->view_where("departments", $where_department)->result();
        }
        $data['employees'] = $this->M_templates->view_where("employees", $where_employee)->result();
        // echo "<pre>";
        // print_r($data['sub_data']);
        $this->load->view('resume/index', $data);
    }
    public function perjob()
    {
        $this->session->set_userdata('func', 'resumetsperjob');
        $data['data'] = $this->Resumes->get_per_job()->result_array();
        $data['sub_data'] = $this->Resumes->get_sub_per_job()->result_array();
        $data['jobs'] = $this->M_templates->view("jobs")->result();
        
        // $this->session->set_userdata('func', 'resumes');
        // if ($this->session->role == 1) {
        //     $where_employee = [
        //         'role >' => $this->session->role
        //     ];
        // } elseif ($this->session->role <= 2) {
        //     $where_employee = [
        //         'discipline' => $this->session->discipline,
        //         'role >' => $this->session->role
        //     ];
        // } else {
        //     $where_employee = [
        //         'id_employee' => $this->session->id,
        //     ];
        // }
        // if ($this->session->role == 1 || $this->session->role == 2) {
        //     $data['disciplines'] = $this->M_templates->view("disciplines")->result();
        // } else {
        //     $where_discipline = [
        //         'id_discipline' => $this->session->discipline,
        //     ];
        //     $data['disciplines'] = $this->M_templates->view_where("disciplines", $where_discipline)->result();
        // }
        // if ($this->session->role == 1 || $this->session->role == 2) {
        //     $data['departments'] = $this->M_templates->view("departments")->result();
        // } else {
        //     $where_department = [
        //         'id_department' => $this->session->department,
        //     ];
        //     $data['departments'] = $this->M_templates->view_where("departments", $where_department)->result();
        // }
        // $data['employees'] = $this->M_templates->view_where("employees", $where_employee)->result();
        // echo "<pre>";
        // print_r($data['sub_data']);
        $this->load->view('resume/perjob', $data);
    }
    public function get_employee($id)
    {
        $data = $this->M_templates->view_where('view_employees',['id_employee'=>$id])->row();
        echo json_encode($data);
    }
    public function get_job($id)
    {
        $data = $this->M_templates->view_where('jobs',['id_job'=>$id])->row();
        echo json_encode($data);
    }
}
