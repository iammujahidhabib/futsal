<?php $this->load->view('template/header'); ?>
<style type="text/css">
	.gagal {
		color: red;
	}
</style>
<!-- Main content -->
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header row">
						<div class="col-sm-12 col-md-6">
							<h4 class="card-title">Create Employee</h4>
						</div>
					</div>
					<div class="card-body">
						<form method="post" action="<?= site_url() ?>employees/create/" enctype="multipart/form-data">
							<div class="form-group row">
								<label for="inp-name" class="col-sm-2 col-form-label">Name</label>
								<div class="col-sm-10">
									<input required type="text" class="form-control" name="name" id="inp-name" placeholder="Employee Name">
								</div>
							</div>
							<div class="form-group row">
								<label for="inp-badge" class="col-sm-2 col-form-label">Badge</label>
								<div class="col-sm-10">
									<input required type="text" class="form-control" name="badge" id="inp-badge" placeholder="Employee Badge">
								</div>
							</div>
							<div class="form-group row">
								<label for="inp-username" class="col-sm-2 col-form-label">Username</label>
								<div class="col-sm-10">
									<input required type="text" class="form-control" name="username" id="inp-username" placeholder="Employee username">
								</div>
							</div>
							<div class="form-group row">
								<label for="inp-email" class="col-sm-2 col-form-label">Email</label>
								<div class="col-sm-10">
									<input required type="email" class="form-control" name="email" id="inp-email" placeholder="Employee email">
								</div>
							</div>
							<div class="form-group row">
								<label for="inp-password" class="col-sm-2 col-form-label">Password</label>
								<div class="col-sm-10">
									<input required type="password" class="form-control" name="password" id="inp-password" placeholder="Employee password">
								</div>
							</div>
							<div class="form-group row">
								<label for="inp-discipline" class="col-sm-2 col-form-label">Discipline</label>
								<div class="col-sm-10">
									<select name="discipline" id="inp-discipline" required class="form-control">
										<option value="" disabled selected></option>
										<?php foreach ($disciplines as $key) { ?>
											<option value="<?= $key->id_discipline ?>"><?= $key->discipline ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
							<div class="form-group row">
								<label for="inp-role" class="col-sm-2 col-form-label">Role</label>
								<div class="col-sm-10">
									<select name="role" id="inp-role" required class="form-control">
										<option value="" disabled selected></option>
										<?php foreach ($role as $key => $value) { ?>
											<option value="<?= $value['id'] ?>"><?= $value['name'] ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
							<div class="form-group row">
								<label for="inp-submit" class="col-sm-2 col-form-label"></label>
								<div class="col-sm-10">
									<input type="submit" name="submit" class="btn btn-primary btn-block" value="Create">
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $this->load->view('template/footer'); ?>