<?php $this->load->view('template/header');
// echo count($proyek_on_duty)."<br>";
// echo count($proyek)."<br>";
?>
<!-- Main content -->
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-6 col-sm-6 col-12">
				<div class="info-box bg-gradient-info">
					<span class="info-box-icon"><i class="fas fa-money" aria-hidden="true"></i></span>

					<div class="info-box-content">
						<span class="info-box-text">Jumlah Pendapatan Bulan ini</span>
						<span class="info-box-number"><?="Rp.".number_format($bulanan[0]->total);?></span>

						<div class="progress">
							<div class="progress-bar" style="width: 70%"></div>
						</div>
					</div>
					<!-- /.info-box-content -->
				</div>
				<!-- /.info-box -->
			</div>
			<div class="col-md-6 col-sm-6 col-12">
				<div class="info-box bg-gradient-info">
					<span class="info-box-icon"><i class="far fa-clipboard"></i></span>

					<div class="info-box-content">
						<span class="info-box-text">Jumlah Order Bulan ini</span>
						<span class="info-box-number"><?=$bulanan[0]->pesanan?></span>

						<div class="progress">
							<div class="progress-bar" style="width: 70%"></div>
						</div>
					</div>
					<!-- /.info-box-content -->
				</div>
				<!-- /.info-box -->
			</div>
		</div>
		<div class="row">
			<div class="col-md-6 col-sm-6 col-12">
				<h5 class="text-center">Data Pendapatan per Bulan</h5>
				<div id="chartTotal"></div>
			</div>
			<div class="col-md-6 col-sm-6 col-12">
				<h5 class="text-center">Data Order per Bulan</h5>
				<div id="chartPesanan"></div>
			</div>
		</div>
		<br>
		<h4 class="text-center">Project Pernikahan Sedang Berjalan</h4>
		<div class="container-fluid card" style="padding: 20px 2% 20px 2%">
			<?php foreach ($proyek_on_duty as $key) : ?>
				<div class="card" style="padding-top: 20px;padding-bottom: 20px">
					<div class="row">
						<div class="col-sm-2 text-center">
							<h5>Tanggal Acara</h5>
							<?= date('d M Y', strtotime($key->tanggal_acara)) ?>
						</div>
						<div class="col-sm-3">
							<h5><?= $key->member ?></h5>
							<p><?= $key->keterangan_transaksi ?></p>
						</div>
						<div class="col-sm-3 text-center">
							<h5>Progress Persiapan</h5>
							<!-- <h5><?= $key->persiapan ?></h5> -->
							<?= $key->keterangan_persiapan ?>
						</div>
						<div class="col-sm-3 text-center">
							<h5>Progress Hari H</h5>
							<!-- <h5><?= $key->hari_h ?></h5> -->
							<?= $key->keterangan_hari_h ?>
						</div>
						<div class="col-sm text-center">
							<a href="<?= base_url() ?>order/detail/<?= $key->id_transaksi ?>" class="btn btn-secondary btn-block btn-sm"><i class="fa fa-eye"></i></a>
							<a href="<?= base_url() ?>order/reminder/<?= $key->id_transaksi ?>" class="btn btn-warning btn-block btn-sm text-white"><i class="fa fa-clock" aria-hidden="true"></i></a>
							<!-- <?php if ($key->status_transaksi != 7) { ?> -->
							<?php
										$startDate = time();
										// echo $startDate;
										// echo date('Y-m-d', $startDate)."<br>";
										// echo date('Y-m-d', strtotime('+1 day', $startDate));
										if ($key->tanggal_acara == date('Y-m-d', strtotime('+1 day', $startDate)) || $key->tanggal_acara <= date('Y-m-d', strtotime('+2 day', $startDate))) {
							?>
								<a href="<?= base_url() ?>order/done/<?= $key->id_transaksi ?>" class="btn btn-success btn-block btn-sm"><i class="fas fa-flag-checkered"></i></a>
							<?php
										}
										if ($key->status_transaksi < 5 && $key->tanggal_acara >= date('Y-m-d')) {
							?>
								<a onclick="cancelation(<?= $key->id_transaksi ?>)" class="btn btn-danger btn-block btn-sm text-white"><i class="fas fa-window-close"></i></a>
							<?php
										}
							?>
							<!-- <?php } else {
										echo '<div class="alert alert-danger" role="alert">Pesansan dibatalkan</div>';
									} ?> -->
						</div>
					</div>
					<br>
					<div class="row">
						<div class="col-sm-2 text-center">
							Progress Persiapan
						</div>
						<div class="col-sm">
							<div class="progress">
								<div class="progress-bar" role="progressbar" aria-valuenow="<?= $key->persiapan ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $key->persiapan ?>%">
									<?= $key->persiapan ?>%
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-2 text-center">
							Progress Hari H
						</div>
						<div class="col-sm">
							<div class="progress">
								<div class="progress-bar" role="progressbar" aria-valuenow="<?= $key->hari_h ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $key->hari_h ?>%">
									<?= $key->hari_h ?>%
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach ?>
		</div>
		<br>
		<hr>
		<h4 class="text-center">Project Pernikahan Akan Berjalan</h4>
		<div class="container-fluid card" style="padding: 20px 2% 20px 2%">
			<?php foreach ($proyek as $key) : ?>
				<div class="card" style="padding-top: 20px;padding-bottom: 20px">
					<div class="row">
						<div class="col-sm-2 text-center">
							<h5>Tanggal Acara</h5>
							<?= date('d M Y', strtotime($key->tanggal_acara)) ?>
						</div>
						<div class="col-sm-3">
							<h5><?= $key->member ?></h5>
							<p><?= $key->keterangan_transaksi ?></p>
						</div>
						<div class="col-sm-3 text-center">
							<h5>Progress Persiapan</h5>
							<!-- <h5><?= $key->persiapan ?></h5> -->
							<?= $key->keterangan_persiapan ?>
						</div>
						<div class="col-sm-3 text-center">
							<h5>Progress Hari H</h5>
							<!-- <h5><?= $key->hari_h ?></h5> -->
							<?= $key->keterangan_hari_h ?>
						</div>
						<div class="col-sm text-center">
							<a href="<?= base_url() ?>order/detail/<?= $key->id_transaksi ?>" class="btn btn-secondary btn-block btn-sm">
								<i class="fa fa-eye"></i>
							</a>
							<?php
							if ($key->status_transaksi < 5 && $key->tanggal_acara >= date('Y-m-d')) {
							?>
								<a onclick="cancelation(<?= $key->id_transaksi ?>)" class="btn btn-danger btn-block btn-sm text-white"><i class="fas fa-window-close"></i></a>
							<?php
							}
							?>
						</div>
					</div>
					<br>
					<div class="row">
						<div class="col-sm-2 text-center">
							Progres Persiapan
						</div>
						<div class="col-sm">
							<div class="progress">
								<div class="progress-bar" role="progressbar" aria-valuenow="<?= $key->persiapan ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $key->persiapan ?>%">
									<?= $key->persiapan ?>%
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-2 text-center">
							Progres Hari H
						</div>
						<div class="col-sm">
							<div class="progress">
								<div class="progress-bar" role="progressbar" aria-valuenow="<?= $key->hari_h ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?= $key->hari_h ?>%">
									<?= $key->hari_h ?>%
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach ?>
		</div>
	</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script type="text/javascript">
	function cancelation(id) {
		var prompt = confirm("Apakah yakin akan mengcancel pesanan WO?");
		if (prompt == true) {
			window.location.href = "<?= base_url() ?>order/cancel/" + id;
		}
	}
	$(document).ready(function(){
		var options = {
          series: [{
          name: 'Orders',
          data: [<?php foreach ($tahunan as $key ) {
			  echo $key->pesanan.",";
		  }?>]
        }],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: '55%',
            endingShape: 'rounded'
          },
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          show: true,
          width: 2,
          colors: ['transparent']
        },
        xaxis: {
          categories: [<?php foreach ($tahunan as $key ) {
			  echo "'".date('M',strtotime($key->bulan))."',";
		  }?>],
        },
        fill: {
          opacity: 1
        }
        };

        var chart = new ApexCharts(document.querySelector("#chartPesanan"), options);
        chart.render();
		
		//asdasdasdsad
		var options2 = {
          series: [{
          name: 'Orders',
          data: [<?php foreach ($tahunan as $key ) {
			  echo $key->total.",";
		  }?>]
        }],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: '55%',
            endingShape: 'rounded'
          },
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          show: true,
          width: 2,
          colors: ['transparent']
        },
        xaxis: {
          categories: [<?php foreach ($tahunan as $key ) {
			  echo "'".date('M',strtotime($key->bulan))."',";
		  }?>],
        },
        fill: {
          opacity: 1
        }
        };

        var chart2 = new ApexCharts(document.querySelector("#chartTotal"), options2);
        chart2.render();
	});
</script>
<?php $this->load->view('template/footer'); ?>