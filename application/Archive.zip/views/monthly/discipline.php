<?php $this->load->view('template/header');
if (isset($_GET['date'])) {
    $full_date = $_GET['date'];
    $month = date('m', strtotime($_GET['date']));
    $month_name = date('F', strtotime($_GET['date']));
    $year = date('Y', strtotime($_GET['date']));
} else {
    $full_date = date('Y-m');
    $month = date('m');
    $month_name = date('F');
    $year = date('Y');
}
$d_count = cal_days_in_month(CAL_GREGORIAN, $month, $year);
?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style>
    th {
        padding: 3px !important;
    }
</style>
<!-- Main content -->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-sm-12 col-md-6">
                                <h4 class="card-title">MONTHLY TIME SHEET DISCIPLINE</h4>
                            </div>
                        </div>
                        <!-- <div class="col-sm-12 col-md-6">
                            <a type="button" class="btn btn-primary btn-sm float-right" href="<?= base_url() ?>employees/create">
                                <i class="fa fa-plus"></i> Employee
                            </a>
                        </div> -->
                    </div>
                    <div class="card-body">
                        <div id="example2_wrapper" class="dataTables_wrapper dt-bootstrap4">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="">Discipline</label>
                                        <select aria-placeholder="type job number" name="discipline_id" id="discipline_id" class="form-control select-2" required>
                                            <option value=""></option>
                                            <?php foreach ($disciplines as $key) { ?>
                                                <option value="<?= $key->id_discipline ?>"><?= $key->discipline ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label for="">Date</label>
                                        <input type="month" name="date" id="select_date" class="form-control" value="<?= $full_date ?>">
                                    </div>
                                </div>
                                <div class="col-sm-3" style="vertical-align: middle !important;margin: auto;">
                                    <button id="submit_filter" class="btn btn-primary btn-sm btn-block" style="margin: auto;">Filter</button>
                                    <!-- </div> -->
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="table-responsive" style="padding: 5px;">
                                    <table id="example2" class="table table-bordered small table-hover" role="grid" aria-describedby="example2_info">
                                        <thead class="text-center">
                                            <tr role="row">
                                                <th rowspan="5" style="vertical-align: middle;">No</th>
                                                <th rowspan="5" style="vertical-align: middle;">JOB NUMBER</th>
                                                <th rowspan="5" style="vertical-align: middle;">JOB TITLE</th>
                                                <th rowspan="5" style="vertical-align: middle;">COORDINATOR / MEMBER</th>
                                                <th colspan="<?= $d_count ?>">MAN HOUR</th>
                                                <th rowspan="5" colspan="2" style="vertical-align: middle;">SUB TOTAL MAN<br>HOUR PER JOB</th>
                                                <th rowspan="5" colspan="4" style="vertical-align: middle;">REMARKS</th>
                                            </tr>
                                            <tr role="row">
                                                <th colspan="<?= $d_count ?>"><?= $year ?></th>
                                            </tr>
                                            <tr role="row">
                                                <th colspan="<?= $d_count ?>"><?= $month_name ?></th>
                                            </tr>
                                            <tr role="row">
                                                <?php
                                                for ($i = 1; $i <= $d_count; $i++) { ?>
                                                    <th><?= $i ?></th>
                                                <?php } ?>
                                            </tr>
                                            <tr role="row">
                                                <?php
                                                for ($i = 1; $i <= $d_count; $i++) { ?>
                                                    <th><?= date('D', strtotime($full_date . '-' . $i)); ?></th>
                                                <?php } ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $no = 1;
                                            $is_pok = 0;
                                            $is_proyek = 0;
                                            foreach ($data as $k => $key) {
                                                if (strpos($key['job_number'], "POK") !== FALSE) {
                                                    $is_pok += 1;
                                                } else {
                                                    $is_proyek += 1;
                                                } ?>
                                                <tr>
                                                    <td><?= $no; ?></td>
                                                    <td style="white-space: nowrap;"><?= $key['job_number']; ?></td>
                                                    <td style="white-space: nowrap;"><?= $key['job_title']; ?></td>
                                                    <td><?= $key['subordinated']; ?></td>
                                                    <?php
                                                    $d_count = cal_days_in_month(CAL_GREGORIAN, $month, $year);
                                                    for ($i = 1; $i <= $d_count; $i++) { ?>
                                                        <td><?= $key['m' . $i]; ?></td>
                                                    <?php } ?>
                                                    <td><?= $key['totals']; ?></td>
                                                    <td><?= (isset($sub_data)) ? ($sub_data[0]['totals'] > 0) ? round(($key['totals'] / $sub_data[0]['totals']) * 100) : 0 : 0; ?>%</td>
                                                    <td colspan="4"></td>
                                                </tr>
                                            <?php $no++;
                                            } ?>
                                            <?php
                                            foreach ($sub_data as $k => $key) { ?>
                                                <tr>
                                                    <td colspan="2" style="white-space: nowrap;">Total POK</td>
                                                    <td colspan="2" style="white-space: nowrap;">SUB TOTAL MAN HOUR PER DAY</td>
                                                    <?php
                                                    $d_count = cal_days_in_month(CAL_GREGORIAN, $month, $year);
                                                    for ($i = 1; $i <= $d_count; $i++) { ?>
                                                        <td><?= $key['m' . $i]; ?></td>
                                                    <?php } ?>
                                                    <td colspan="4" style="white-space: nowrap;">TOTAL MAN HOUR PER MONTH</td>
                                                    <td colspan="2"><?= $key['totals'] ?></td>
                                                </tr>
                                            <?php
                                            } ?>
                                            <?php
                                            foreach ($sub_data as $k => $key) {
                                                $total_overtime = 0;
                                            ?>
                                                <tr>
                                                    <td colspan="2"><?= $is_pok ?></td>
                                                    <td colspan="2" style="white-space: nowrap;">OVERTIME PER DAY</td>
                                                    <?php
                                                    $d_count = cal_days_in_month(CAL_GREGORIAN, $month, $year);
                                                    for ($i = 1; $i <= $d_count; $i++) {
                                                        $total_overtime += ($key['m' . $i] - 8 > 0) ? $key['m' . $i] - 8 : 0;
                                                    ?>
                                                        <td><?= ($key['m' . $i] - 8 > 0) ? $key['m' . $i] - 8 : 0 ?></td>
                                                    <?php } ?>
                                                    <td colspan="4">TOTAL OVERTIME PER MONTH</td>
                                                    <td><?= $total_overtime; ?></td>
                                                    <td><?= ($key['totals'] > 0) ? round(($total_overtime / $key['totals']) * 100) : 0 ?>%</td>
                                                </tr>
                                            <?php
                                            } ?>
                                            <tr>
                                                <td colspan="2" style="white-space: nowrap;">Total Proyek</td>
                                            </tr>
                                            <tr>
                                                <td colspan="2"><?= $is_proyek ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <br>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="card" style="padding: 5%;">
                                            <div class="card-header text-center font-weight-bold">MONTHLY <u>DISCIPLINE</u> MAN HOUR DISTRIBUTION PERCENTAGE</div>
                                            <div class="card-body">
                                                <canvas id="pie_chart" style="height: 250px;width: 100%;"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="card" style="padding: 5%;">
                                            <div class="card-header text-center font-weight-bold">MONTHLY <u>DISCIPLINE</u> MAN HOUR DISTRIBUTION</div>
                                            <div class="card-body">
                                                <canvas id="bar_chart" style="height: 250px;width: 100%;"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="card" style="padding: 5%;">
                                            <div class="card-header text-center font-weight-bold">MONTHLY <u>DISCIPLINE</u> OVERTIME PERCENTAGE</div>
                                            <div class="card-body">
                                                <canvas id="pie2_chart" style="height: 250px;width: 100%;"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script type="text/javascript">
    $("#submit_filter").click(function() {
        var _discipline_id = $("#discipline_id").val()
        var _select_date = $("#select_date").val()
        var _url = "<?= site_url('monthly/discipline?') ?>discipline=" + _discipline_id + "&date=" + _select_date
        // console.log(_discipline_id);
        if (!_discipline_id) {
            alert("Please select discipline");
        } else {
            // console.log(_discipline_id);
            window.location.href = _url
        }
    });
    $(document).ready(function() {
        <?php if (isset($_GET['discipline'])) { ?>
            console.log(<?= $_GET['discipline'] ?>);
            $("#discipline_id").val("<?= $_GET['discipline'] ?>");
            // $selected_employee = $_GET['employee'];
        <?php } else { ?>
            $("#discipline_id").val("1");
        <?php } ?>
        $("#discipline_id").select2();
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    var div_pie = document.getElementById('pie_chart').getContext('2d');
    var pie_chart = new Chart(div_pie, {
        type: 'pie',
        data: {
            labels: <?= json_encode($chart_data['labels']) ?>,
            datasets: [{
                label: '%',
                data: <?= json_encode($chart_data['percentage']) ?>,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.8)',
                    'rgba(54, 162, 235, 0.8)',
                    'rgba(255, 206, 86, 0.8)',
                    'rgba(75, 192, 192, 0.8)',
                    'rgba(153, 102, 255, 0.8)',
                    'rgba(255, 159, 64, 0.8)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    var div_bar = document.getElementById('bar_chart').getContext('2d');
    var bar_chart = new Chart(div_bar, {
        type: 'bar',
        data: {
            labels: <?= json_encode($chart_data['labels']) ?>,
            datasets: [{
                label: '# of Votes',
                data: <?= json_encode($chart_data['distribution']) ?>,
                backgroundColor: [
                    'rgba(54, 162, 235, 0.8)',
                ],
                borderColor: [
                    'rgba(54, 162, 235, 1)',
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    var div_pie2 = document.getElementById('pie2_chart').getContext('2d');
    var pie2_chart = new Chart(div_pie2, {
        type: 'pie',
        data: {
            labels: ["Normal time", "Overtime"],
            datasets: [{
                label: '%',
                data: [<?= ($sub_data[0]['totals'] > 0) ? 100 - round(($total_overtime / $sub_data[0]['totals']) * 100) : 0 ?>, <?= ($sub_data[0]['totals'] > 0) ? round(($total_overtime / $sub_data[0]['totals']) * 100) : 0 ?>],
                backgroundColor: [
                    'rgba(54, 162, 235, 0.8)',
                    'rgba(255, 99, 132, 0.8)',
                ],
                borderColor: [
                    'rgba(54, 162, 235, 0.8)',
                    'rgba(255, 99, 132, 1)',
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
<?php $this->load->view('template/footer'); ?>