<?php $this->load->view('template/header');
?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<!-- Main content -->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <?= $this->session->flashdata("message") ?>
            </div>
            <div class="col-sm-12" style="padding: 20px;">
                <h1 class="text-center">DAILY EMPLOYEE JOB TIME SHEET</h1>
                <?php if ($this->session->role <= 2) {
                    if (isset($_GET['employee'])) {
                        $selected_employee = $_GET['employee'];
                    }
                ?>
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="">Employee</label>
                                <select aria-placeholder="type job number" name="employee_id" id="employee_id" class="form-control select-2" required>
                                    <option value=""></option>
                                    <?php foreach ($employees as $key) { ?>
                                        <option value="<?= $key->id_employee ?>"><?= $key->name ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label for="">Date</label>
                                <input type="date" name="date" id="select_date" class="form-control" value="<?= date('Y-m-d') ?>">
                            </div>
                        </div>
                        <div class="col-sm-3" style="vertical-align: middle !important;margin: auto;">
                            <button id="submit_filter" class="btn btn-primary btn-sm btn-block" style="margin: auto;">Filter</button>
                            <!-- </div> -->
                        </div>
                    </div>
                <?php } ?>
                <table class="table table-bordered">
                    <thead class="text-center">
                        <tr>
                            <th>NO</th>
                            <th>JOB NUMBER</th>
                            <th>JOB TITLE</th>
                            <th>COORDINATOR/MEMBER</th>
                            <th>MAN HOUR<br><?= date('d F Y') ?></th>
                            <th colspan="2">DETAIL PEKERJAAN</th>
                        </tr>
                    </thead>
                    <tbody id="tbody_sub_job">
                        <?php $no = 1;
                        $total_hour = 0;
                        $is_pok = 0;
                        $is_proyek = 0;
                        foreach ($time_sheets as $key) {
                            if (strpos($key->job_number, "POK") !== FALSE) {
                                $is_pok += 1;
                            } else {
                                $is_proyek += 1;
                            }
                        ?>
                            <tr>
                                <td><?= $no ?></td>
                                <td>
                                    <input type="text" name="job_number[]" id="job_number" class="form-control" readonly value="<?= $key->job_number ?>">
                                </td>
                                <td>
                                    <input type="text" name="job_title[]" id="job_title" class="form-control" readonly value="<?= $key->job_title ?>">
                                </td>
                                <td>
                                    <input type="text" name="type[]" id="type" class="form-control" readonly value="<?= $key->subordinated ?>">
                                </td>
                                <td>
                                    <input type="number[]" name="man_hour" id="man_hour" class="form-control" readonly value="<?= $key->hour ?>">
                                </td>
                                <td colspan="2">
                                    <textarea name="detail_pekerjaan[]" id="detail_pekerjaan" cols="30" rows="3" class="form-control" readonly><?= $key->detail_job ?></textarea>
                                </td>
                            </tr>
                        <?php $total_hour += $key->hour;
                            $no++;
                        } ?>
                        <?php if (empty($time_sheets)) { ?>
                            <tr>
                                <td colspan="7" class="text-center bg-info">No data</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="2">TOTAL POK</th>
                            <th colspan="2">SUB TOTAL MAN HOUR PER DAY</th>
                            <th><?= $total_hour ?></th>
                            <th>TOTAL MAN HOUR PER MONTH</th>
                            <th><?= (!empty($hour_per_month)) ? $hour_per_month[0]->total : 0 ?></th>
                        </tr>
                        <tr>
                            <th colspan="2"><?= $is_pok ?></th>
                            <th colspan="2">OVERTIME PER DAY</th>
                            <th><?= ($total_hour - 8 > 0) ? $total_hour - 2 : 0 ?></th>
                            <th>TOTAL OVERTIME PER MONTH</th>
                            <th><?= ($hour_per_month[0]->total - ($day_per_month * 8) > 0) ? $hour_per_month[0]->total - ($day_per_month * 8) : 0 ?></th>
                        </tr>
                        <tr>
                            <th colspan="2">TOTAL PROYEK</th>
                            <th colspan="2">Made Date</th>
                            <th><?= $this_date ?></th>
                        </tr>
                        <tr>
                            <th colspan="2"><?= $is_proyek ?></th>
                            <th colspan="2">Approval Date</th>
                            <th></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <div class="col-sm-9"></div>
            <div class="col-sm">
                <?php if (!empty($time_sheets)) { ?>
                    <?php if ($this->session->role <= 2) { ?>
                        <?php if ($is_self != "y" && $status_approve == "Belum diapprove") { ?>
                            <a href="<?= site_url('dailytimesheet/approve/') ?><?= $this_employee_id ?>/1/<?= $this_date ?>" class="btn btn-success">APPROVE</a>
                            <a href="#" class="btn btn-danger">NOT APPROVE</a>
                        <?php } else {
                            echo "Status : $status_approve";
                        } ?>
                    <?php } else {
                        echo "Status : $status_approve";
                    } ?>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $("#submit_filter").click(function() {
        var _employee_id = $("#employee_id").val()
        var _select_date = $("#select_date").val()
        var _url = "<?= site_url('dailytimesheet/review?') ?>employee=" + _employee_id + "&date=" + _select_date
        // console.log(_employee_id);
        if (!_employee_id) {
            alert("Please select employee");
        } else {
            // console.log(_employee_id);
            window.location.href = _url
        }
    });
    $(document).ready(function() {
        <?php if (isset($_GET['employee'])) { ?>
            console.log(<?= $_GET['employee'] ?>);
            $("#employee_id").val("<?= $_GET['employee'] ?>");
            // $selected_employee = $_GET['employee'];
        <?php } ?>
        $("#employee_id").select2();
    });
</script>
<?php $this->load->view('template/footer'); ?>