<?php $this->load->view('template/header'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<!-- Main content -->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <form action="<?= site_url() ?>dailytimesheet/create" method="post">
                <div class="col-sm-12" style="padding: 20px;">
                    <h1 class="text-center">DAILY EMPLOYEE JOB TIME SHEET</h1>
                    <table class="table small table-bordered">
                        <thead class="text-center">
                            <tr>
                                <th>NO</th>
                                <th>JOB NUMBER</th>
                                <th>JOB TITLE</th>
                                <th>COORDINATOR/MEMBER</th>
                                <th>MAN HOUR<br><?= date('d F Y') ?></th>
                                <th colspan="2">DETAIL PEKERJAAN</th>
                                <th>
                                    <button class="btn btn-default btn-sm" id="add_sub_job">add sub-job</button>
                                </th>
                            </tr>
                        </thead>
                        <tbody id="tbody_sub_job">
                            <tr>
                                <td></td>
                                <td>
                                    <select aria-placeholder="type job number" name="job_number[]" id="job_number" class="form-control select-2">
                                        <option value=""></option>
                                        <?php foreach ($jobs as $key) { ?>
                                            <option value="<?= $key->id_job ?>"><?= $key->job_number ?></option>
                                        <?php } ?>
                                    </select>
                                </td>
                                <td>
                                    <input type="text" name="job_title[]" id="job_title" class="form-control">
                                </td>
                                <td>
                                    <select name="type[]" id="type" class="form-control">
                                        <option value="MEMBER">MEMBER</option>
                                        <option value="COORDINATOR">COORDINATOR</option>
                                    </select>
                                </td>
                                <td>
                                    <input type="number" name="man_hour[]" min="0" id="man_hour" class="form-control">
                                </td>
                                <td colspan="2">
                                    <textarea name="detail_pekerjaan[]" id="detail_pekerjaan" cols="30" rows="3" class="form-control"></textarea>
                                </td>
                                <td>
                                </td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="2">TOTAL POK</th>
                                <th colspan="2">SUB TOTAL MAN HOUR PER DAY</th>
                                <th></th>
                                <th>TOTAL MAN HOUR PER MONTH</th>
                                <th></th>
                            </tr>
                            <tr>
                                <th colspan="2"></th>
                                <th colspan="2">OVERTIME PER DAY</th>
                                <th></th>
                                <th>TOTAL OVERTIME PER MONTH</th>
                                <th></th>
                            </tr>
                            <tr>
                                <th colspan="2">TOTAL PROYEK</th>
                                <th colspan="2">Made Date</th>
                                <th><input type="date" name="date" id="date" class="form-control" value="<?= date('Y-m-d') ?>" required></th>
                            </tr>
                            <tr>
                                <th colspan="2"></th>
                                <th colspan="2">Approval Date</th>
                                <th></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-primary float-right">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $("#add_sub_job").click(function() {
        event.preventDefault();
        var _html = `<tr>
                            <td></td>
                            <td>
                                 <select aria-placeholder="type job number" name="job_number[]" id="job_number" class="form-control select-2">
                                    <option value=""></option>
                                    <?php foreach ($jobs as $key) { ?>
                                        <option value="<?= $key->id_job ?>"><?= $key->job_number ?></option>
                                    <?php } ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="job_title[]" id="job_title" class="form-control">
                            </td>
                            <td>
                                <select name="type[]" id="type" class="form-control">
                                    <option value="MEMBER">MEMBER</option>
                                    <option value="COORDINATOR">COORDINATOR</option>
                                </select>
                            </td>
                            <td>
                                <input type="number" name="man_hour[]" min="0" id="man_hour" class="form-control">
                            </td>
                            <td colspan="2">
                                <textarea name="detail_pekerjaan[]" id="detail_pekerjaan" rows="3" class="form-control"></textarea>
                            </td>
                            <td>
                                <button class="btn btn-default btn-sm" id="remove_sub_job">remove sub-job</button>
                            </td>
                        </tr>`;
        $("#tbody_sub_job").append(_html);
    });
    $(document).ready(function() {
        $(document).on("mouseover",".select-2", function() {
            $(this).select2();
        });
        $("#tbody_sub_job").on('click', '#remove_sub_job', function() {
            event.preventDefault();

            $(this).parent().parent().remove();
        });
        $(document).on('select2:select', '.select-2', function(e) {
            e.preventDefault();

            var _id_job = $(this).val();
            console.log(_id_job);
            // $(this).parent().parent().find("#job_title").val(_id_job);
            var _job_title = $.ajax({
                type: 'GET',
                url: "<?= site_url() ?>dailytimesheet/getJobTitle/" + _id_job,
                dataType: 'json',
                async: false,
                // success: function(data) {
                //     _job_title = data;//$(this).find("#job_title").val(data);
                // }
            }).responseJSON;
            $(this).parent().parent().find("#job_title").val(_job_title);
            // $.getJSON("<?= site_url() ?>dailytimesheet/getJobTitle/" + _id_job, function(data) {
            //     // return data
            // });
            // console.log(_job_title.responseJSON);
        });
    });
</script>
<?php $this->load->view('template/footer'); ?>