<?php $this->load->view('template/header'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<!-- Main content -->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <form action="<?= site_url() ?>dailytimesheet/update" method="post">
                <div class="col-sm-12" style="padding: 20px;">
                    <h1 class="text-center">DAILY EMPLOYEE JOB TIME SHEET</h1>
                    <table class="table table-bordered">
                        <thead class="text-center">
                            <tr>
                                <th>NO</th>
                                <th>JOB NUMBER</th>
                                <th>JOB TITLE</th>
                                <th>COORDINATOR/MEMBER</th>
                                <th>MAN HOUR<br><?= date('d F Y') ?></th>
                                <th colspan="2">DETAIL PEKERJAAN</th>
                                <th>
                                    <button class="btn btn-default btn-sm" id="add_sub_job">add sub-job</button>
                                </th>
                            </tr>
                        </thead>
                        <tbody id="tbody_sub_job">
                            <?php $no = 1;
                            $total_hour = 0;
                            $is_pok = 0;
                            $is_proyek = 0;
                            foreach ($time_sheets as $ts) {
                                if (strpos($ts->job_number, "POK") !== FALSE) {
                                    $is_pok += 1;
                                } else {
                                    $is_proyek += 1;
                                } ?>
                                <tr>
                                    <td>
                                        <?= $no ?>
                                        <input type="hidden" name="id[]" value="<?= $ts->id_time_sheet ?>">
                                    </td>
                                    <td>
                                        <select aria-placeholder="type job number" name="job_number[]" id="job_number" class="form-control select-2 inp_job_number">
                                            <option value="" selected disabled></option>
                                            <?php foreach ($jobs as $key) { ?>
                                                <option value="<?= $key->id_job ?>" <?= ($ts->id_job == $key->id_job) ? "selected" : "" ?>><?= $key->job_number ?></option>
                                            <?php } ?>
                                        </select>
                                    </td>
                                    <td>
                                        <input type="text" value="<?= $ts->job_title ?>" name="job_title[]" id="job_title" class="form-control">
                                    </td>
                                    <td>
                                        <select name="type[]" id="type" class="form-control inp_type">
                                            <option value="member">MEMBER</option>
                                            <option value="coordinator">COORDINATOR</option>
                                        </select>
                                    </td>
                                    <td>
                                        <input type="number" value="<?= $ts->hour ?>" name="man_hour[]" min="0" id="man_hour" class="form-control">
                                    </td>
                                    <td colspan="2">
                                        <textarea name="detail_pekerjaan[]" id="detail_pekerjaan" cols="30" rows="3" class="form-control"><?= $ts->detail_job ?></textarea>
                                    </td>
                                    <td>
                                        <button id="delete_time_sheet" class="btn btn-danger btn-sm" data-id="<?= $ts->id_time_sheet ?>">Hapus</button>
                                    </td>
                                </tr>
                            <?php $total_hour += $ts->hour;
                                $no++;
                            } ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="2">TOTAL POK</th>
                                <th colspan="2">SUB TOTAL MAN HOUR PER DAY</th>
                                <th><?= $total_hour ?></th>
                                <th>TOTAL MAN HOUR PER MONTH</th>
                                <th><?= $hour_per_month[0]->total ?></th>
                            </tr>
                            <tr>
                                <th colspan="2"><?= $is_pok ?></th>
                                <th colspan="2">OVERTIME PER DAY</th>
                                <th><?= ($total_hour - 8 > 0) ? $total_hour - 2 : 0 ?></th>
                                <th>TOTAL OVERTIME PER MONTH</th>
                                <th><?= ($hour_per_month[0]->total - ($day_per_month * 8) > 0) ? $hour_per_month[0]->total - ($day_per_month * 8) : 0 ?></th>
                            </tr>
                            <tr>
                                <th colspan="2">TOTAL PROYEK</th>
                                <th colspan="2">Made Date</th>
                                <th><input type="date" name="date" id="date" class="form-control" value="<?= $time_sheets[0]->date ?>" required></th>
                            </tr>
                            <tr>
                                <th colspan="2"><?= $is_proyek ?></th>
                                <th colspan="2">Approval Date</th>
                                <th></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="col-sm-12">
                    <button type="submit" class="btn btn-primary float-right">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    function setSelected() {
        var json = <?= json_encode($time_sheets) ?>;
        console.log(json);
        for (let index = 0; index < json.length; index++) {
            // const element = array[index];
            $(".inp_job_number").eq(index).val(json[index].job_title);
            $(".inp_type").eq(index).val(json[index].subordinated);
        }
        console.log($(".inp_job_number").eq(0).val());
    }
    $(document).on("click", "#delete_time_sheet", function() {
        event.preventDefault()
        var _id = $(this).data('id')
        console.log(_id);
        $(this).parent().parent().remove();
        var _url ="<?=site_url('dailytimesheet/delete?id=')?>"+_id
        console.log(_url);
        $.getJSON(_url, function(data) {
            console.log(data);
            alert(data.message + " menghapus Daily Employee Job Time Sheet");
        });
    })
    $("#add_sub_job").click(function() {
        event.preventDefault();
        // $(".select-2").select2('destroy');
        var _html = `<tr>
                            <td>
                                <input type="hidden" name="id[]" value="-">
                            </td>
                            <td>
                                 <select aria-placeholder="type job number" name="job_number[]" id="job_number" class="form-control select-2">
                                    <option value=""></option>
                                    <?php foreach ($jobs as $key) { ?>
                                        <option value="<?= $key->id_job ?>"><?= $key->job_number ?></option>
                                    <?php } ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="job_title[]" id="job_title" class="form-control">
                            </td>
                            <td>
                                <select name="type[]" id="type" class="form-control">
                                    <option value="MEMBER">MEMBER</option>
                                    <option value="COORDINATOR">COORDINATOR</option>
                                </select>
                            </td>
                            <td>
                                <input type="number" name="man_hour[]" min="0" id="man_hour" class="form-control">
                            </td>
                            <td colspan="2">
                                <textarea name="detail_pekerjaan[]" id="detail_pekerjaan" rows="3" class="form-control"></textarea>
                            </td>
                            <td>
                                <button class="btn btn-danger btn-sm" id="remove_sub_job">remove sub-job</button>
                            </td>
                        </tr>`;
        $("#tbody_sub_job").append(_html);
    });
    $(document).ready(function() {
        $(document).on("mouseover", ".select-2", function() {
            $(this).select2();
        });
        $("#tbody_sub_job").on('click', '#remove_sub_job', function() {
            event.preventDefault();

            $(this).parent().parent().remove();
        });
        $(document).on('select2:select', '.select-2', function(e) {
            e.preventDefault();

            var _id_job = $(this).val();
            console.log(_id_job);
            // $(this).parent().parent().find("#job_title").val(_id_job);
            var _job_title = $.ajax({
                type: 'GET',
                url: "<?= site_url() ?>dailytimesheet/getJobTitle/" + _id_job,
                dataType: 'json',
                async: false,
                // success: function(data) {
                //     _job_title = data;//$(this).find("#job_title").val(data);
                // }
            }).responseJSON;
            $(this).parent().parent().find("#job_title").val(_job_title);
            // $.getJSON("<?= site_url() ?>dailytimesheet/getJobTitle/" + _id_job, function(data) {
            //     // return data
            // });
            // console.log(_job_title.responseJSON);
        });
        // setSelected();
    });
</script>
<?php $this->load->view('template/footer'); ?>