<?php $this->load->view('template/header');
// echo count($proyek_on_duty)."<br>";
// echo count($proyek)."<br>";
?>
<!-- Main content -->
<div class="content">
	<div class="container">
		<div class="row">
        <h1>WELCOME TO e-JOTS</h1>
        </div>
	</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<?php $this->load->view('template/footer'); ?>