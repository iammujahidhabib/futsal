<?php $this->load->view('template/header');
// echo count($proyek_on_duty)."<br>";
// echo count($proyek)."<br>";
?>
<!-- Main content -->
<div class="content">
	<div class="container-fluid">
        <h1>WELCOME TO e-JOTS</h1>
		<div class="row">
        </div>
	</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<?php $this->load->view('template/footer'); ?>