<?php $this->load->view('template/header');
if (isset($_GET['date'])) {
    $full_date = $_GET['date'];
    $month = date('m', strtotime($_GET['date']));
    $month_name = date('F', strtotime($_GET['date']));
    $year = date('Y', strtotime($_GET['date']));
} else {
    $full_date = date('Y-m');
    $month = date('m');
    $month_name = date('F');
    $year = date('Y');
}
?>
<?php
if (isset($_GET['start']) && isset($_GET['end'])) {
    $start = $_GET['start'];
    $end = $_GET['end'];
} else {
    $start = date('Y-01-01');
    $end = date('Y-m-d');
}
$start    = (new DateTime($start))->modify('first day of this month');
$end      = (new DateTime($end))->modify('first day of next month');
$interval = DateInterval::createFromDateString('1 month');
$period   = new DatePeriod($start, $interval, $end);
$d_count = 0;
foreach ($period as $dt) {
    $d_count++;
}

$list_labels = [];
$list_percentage = [];
$list_hour = [];
foreach ($data as $key => $value) {
    array_push($list_labels, $value['job_number']);
    array_push($list_percentage, (isset($sub_data)) ? ($sub_data[0]['totals'] > 0) ? round(($value['totals'] / $sub_data[0]['totals']) * 100) : 0 : 0);
    array_push($list_hour, $value['totals']);
}
?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style>
    th {
        padding: 3px !important;
    }
</style>
<!-- Main content -->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-sm-12 col-md-6">
                                <h4 class="card-title">RESUME OF JOB TIME SHEET</h4>
                            </div>
                        </div>
                        <!-- <div class="col-sm-12 col-md-6">
                            <a type="button" class="btn btn-primary btn-sm float-right" href="<?= base_url() ?>employees/create">
                                <i class="fa fa-plus"></i> Employee
                            </a>
                        </div> -->
                    </div>
                    <div class="card-body">
                        <div id="example2_wrapper" class="dataTables_wrapper dt-bootstrap4">
                            <div class="row">
                                <?php if ($this->session->role <= 2) {  ?>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="">Employee</label>
                                            <select aria-placeholder="type job number" name="employee_id" id="employee_id" class="form-control select-2" required>
                                                <option value=""></option>
                                                <?php foreach ($employees as $key) { ?>
                                                    <option value="<?= $key->id_employee ?>"><?= $key->name ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Discipline</label>
                                            <select disabled aria-placeholder="type job number" name="discipline_id" id="discipline_id" class="form-control" required>
                                                <option value=""></option>
                                                <?php foreach ($disciplines as $key) { ?>
                                                    <option value="<?= $key->id_discipline ?>"><?= $key->discipline ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Department</label>
                                            <select disabled aria-placeholder="type job number" name="department_id" id="department_id" class="form-control" required>
                                                <option value=""></option>
                                                <?php foreach ($departments as $key) { ?>
                                                    <option value="<?= $key->id_department ?>"><?= $key->department ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                <?php } ?>
                                <div class="col-sm-6">
                                    <div class="form-group row">
                                        <div class="col-sm-6">
                                            <label for="">Start</label>
                                            <input type="date" name="daterange" id="start_date" class="form-control" value="<?= $start->format('Y-m-d') ?>" />
                                        </div>
                                        <div class="col-sm-6">
                                            <label for="">End</label>
                                            <input type="date" name="daterange" id="end_date" class="form-control" value="<?= $end->format('Y-m-d') ?>" />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <button id="submit_filter" class="btn btn-primary btn-sm btn-block" style="margin: auto;">Filter</button>
                                    </div>
                                </div>
                                <!-- <div class="col-sm-4">
                                </div> -->
                                <div class="col-sm-3" style="vertical-align: middle !important;margin: auto;">
                                    <!-- </div> -->
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="table-responsive" style="padding: 5px;">
                                    <table id="example2" class="table table-bordered small table-hover" role="grid" aria-describedby="example2_info">
                                        <thead class="text-center">
                                            <tr role="row">
                                                <th rowspan="5" style="vertical-align: middle;">No</th>
                                                <th rowspan="5" style="vertical-align: middle;">JOB NUMBER</th>
                                                <th rowspan="5" style="vertical-align: middle;">JOB TITLE</th>
                                                <th rowspan="5" style="vertical-align: middle;">COORDINATOR / MEMBER</th>
                                                <th colspan="<?= $d_count ?>">MAN HOUR</th>
                                                <th rowspan="5" colspan="2" style="vertical-align: middle;">SUB TOTAL MAN<br>HOUR PER JOB</th>
                                                <th rowspan="5" colspan="4" style="vertical-align: middle;">REMARKS</th>
                                            </tr>
                                            <tr role="row">
                                                <?php
                                                foreach ($period as $dt) {
                                                ?>
                                                    <th class="y_<?= $dt->format('Y') ?>">
                                                        <?= $dt->format('Y') ?>
                                                    </th>
                                                <?php
                                                }
                                                ?>
                                            </tr>
                                            <tr role="row">
                                                <?php
                                                foreach ($period as $dt) {
                                                ?>
                                                    <th>
                                                        <?= $dt->format("M") ?>
                                                    </th>
                                                <?php
                                                }
                                                ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $no = 1;
                                            $is_pok = 0;
                                            $is_proyek = 0;
                                            foreach ($data as $k => $key) {
                                                if (strpos($key['job_number'], "POK") !== FALSE) {
                                                    $is_pok += 1;
                                                } else {
                                                    $is_proyek += 1;
                                                } ?>
                                                <tr>
                                                    <td><?= $no; ?></td>
                                                    <td style="white-space: nowrap;"><?= $key['job_number']; ?></td>
                                                    <td style="white-space: nowrap;"><?= $key['job_title']; ?></td>
                                                    <td><?= $key['subordinated']; ?></td>
                                                    <?php
                                                    foreach ($period as $dt) { ?>
                                                        <td><?= $key['m_' . $dt->format("Y_m")]; ?></td>
                                                    <?php } ?>
                                                    <td><?= $key['totals']; ?></td>
                                                    <td><?= (isset($sub_data)) ? ($sub_data[0]['totals'] > 0) ? round(($key['totals'] / $sub_data[0]['totals']) * 100) : 0 : 0; ?>%</td>
                                                    <td colspan="4"></td>
                                                </tr>
                                            <?php $no++;
                                            } ?>
                                            <?php
                                            foreach ($sub_data as $k => $key) { ?>
                                                <tr>
                                                    <td colspan="2" style="white-space: nowrap;">Total POK</td>
                                                    <td colspan="2" style="white-space: nowrap;">SUB TOTAL MAN HOUR PER DAY</td>
                                                    <?php
                                                    foreach ($period as $dt) { ?>
                                                        <td><?= $key['m_' . $dt->format("Y_m")]; ?></td>
                                                    <?php } ?>
                                                    <td colspan="4" style="white-space: nowrap;">TOTAL MAN HOUR PER MONTH</td>
                                                    <td colspan="2"><?= $key['totals'] ?></td>
                                                </tr>
                                            <?php
                                            } ?>
                                            <?php
                                            foreach ($sub_data as $k => $key) {
                                                $total_overtime = 0;
                                            ?>
                                                <tr>
                                                    <td colspan="2"><?= $is_pok ?></td>
                                                    <td colspan="2" style="white-space: nowrap;">OVERTIME PER DAY</td>
                                                    <?php
                                                    foreach ($period as $dt) { ?>
                                                        <td><?= ($key['m_' . $dt->format("Y_m")] - 8 > 0) ? $key['m_' . $dt->format("Y_m")] - 8 : 0 ?></td>
                                                    <?php } ?>
                                                    <td colspan="4">TOTAL OVERTIME PER MONTH</td>
                                                    <td><?= $total_overtime; ?></td>
                                                    <td><?= ($key['totals'] > 0) ? round(($total_overtime / $key['totals']) * 100) : 0 ?>%</td>
                                                </tr>
                                            <?php
                                            } ?>
                                            <tr>
                                                <td colspan="2" style="white-space: nowrap;">Total Proyek</td>
                                            </tr>
                                            <tr>
                                                <td colspan="2"><?= $is_proyek ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <br>
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="card" style="padding: 5%;">
                                            <div class="card-header text-center font-weight-bold">MAN HOUR RESUME DISTRIBUTION PERCENTAGE</div>
                                            <div class="card-body">
                                                <canvas id="pie_chart" style="height: 250px;width: 100%;"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="card" style="padding: 5%;">
                                            <div class="card-header text-center font-weight-bold">MAN HOUR RESUME DISTRIBUTION</div>
                                            <div class="card-body">
                                                <canvas id="bar_chart" style="height: 250px;width: 100%;"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="card" style="padding: 5%;">
                                            <div class="card-header text-center font-weight-bold">MONTHLY <u>EMPLOYEE</u> OVERTIME PERCENTAGE</div>
                                            <div class="card-body">
                                                <canvas id="pie2_chart" style="height: 250px;width: 100%;"></canvas>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script type="text/javascript">
    function hapus(id) {
        var konfirmasi = confirm('Anda yakin akan menghapus?');
        if (konfirmasi == true) {
            window.location.href = '<?= base_url() ?>employees/delete/' + id;
        }
    }
    <?php if ($this->session->role <= 2) { ?>
        $("#employee_id").change(function() {
            var _url = "<?= site_url('resume/get_employee/') ?>" + $("#employee_id").val()
            $.getJSON(_url, function(data) {
                console.log(data);
                $("#discipline_id").val(data.discipline);
                $("#department_id").val(data.department);
            })
        });
    <?php } ?>
    $("#submit_filter").click(function() {
        var _employee_id = $("#employee_id").val()
        var _discipline_id = $("#discipline_id").val()
        var _department_id = $("#department_id").val()
        var _end_date = $("#end_date").val()
        var _start_date = $("#start_date").val()
        var _url = "<?= site_url('resume/?') ?>start=" + _start_date + "&end=" + _end_date
        // console.log(_employee_id);
        <?php if ($this->session->role <= 2) { ?>
            if (!_employee_id) {
                alert("Please select employee");
            } else {
                _url += "&employee=" + _employee_id;
                window.location.href = _url;
            }
        <?php } else { ?>
            window.location.href = _url;
        <?php } ?>
    });
    $(document).ready(function() {
        <?php if (isset($_GET['employee'])) { ?>
            console.log(<?= $_GET['employee'] ?>);
            $("#employee_id").val("<?= $_GET['employee'] ?>");
            // $selected_employee = $_GET['employee'];
        <?php } else { ?>
            $("#employee_id").val("<?= $this->session->id ?>");
        <?php } ?>
        $("#employee_id").select2();
    });
</script>
<script>
    console.log(<?= json_encode($list_percentage) ?>);
    var div_pie = document.getElementById('pie_chart').getContext('2d');
    var pie_chart = new Chart(div_pie, {
        type: 'pie',
        data: {
            labels: <?= json_encode($list_labels) ?>,
            datasets: [{
                label: '%',
                data: <?= json_encode($list_percentage) ?>,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.8)',
                    'rgba(54, 162, 235, 0.8)',
                    'rgba(255, 206, 86, 0.8)',
                    'rgba(75, 192, 192, 0.8)',
                    'rgba(153, 102, 255, 0.8)',
                    'rgba(255, 159, 64, 0.8)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    var div_bar = document.getElementById('bar_chart').getContext('2d');
    var bar_chart = new Chart(div_bar, {
        type: 'bar',
        data: {
            labels: <?= json_encode($list_labels) ?>,
            datasets: [{
                label: '# of Votes',
                data: <?= json_encode($list_hour) ?>,
                backgroundColor: [
                    'rgba(54, 162, 235, 0.8)',
                ],
                borderColor: [
                    'rgba(54, 162, 235, 1)',
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
<?php $this->load->view('template/footer'); ?>