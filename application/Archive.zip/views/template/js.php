<!-- <script src="<?= base_url() ?>asset/adminLTE/plugins/jquery/jquery.min.js"></script> -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js" integrity="sha512-pHVGpX7F/27yZ0ISY+VVjyULApbDlD0/X0rgGbTqCE7WFW5MezNTWG/dnhtbBuICzsd0WQPgpE4REBLv+UqChw==" crossorigin="anonymous"></script> -->
<!-- <script src="<?= base_url() ?>asset/jquery.mask.min.js"></script> -->
<script src="<?= base_url() ?>asset/adminLTE/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url() ?>asset/adminLTE/dist/js/adminlte.min.js"></script>
<script defer src="<?= base_url() ?>asset/fontawesome/js/all.js"></script>
<!-- DataTables -->
<script src="<?= base_url() ?>asset/adminLTE/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>asset/adminLTE/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?= base_url() ?>asset/adminLTE/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?= base_url() ?>asset/adminLTE/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>