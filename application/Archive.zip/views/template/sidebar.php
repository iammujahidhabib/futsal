<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-light bg-dark elevation-4 text-white">
  <!-- Brand Logo -->
  <a href="<?= base_url() ?>admin" class="brand-link text-white text-center">
    <!-- <img src="<?= base_url() ?>asset/adminLTE/dist/img/logoWO.jpg" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8"> -->
    <span class="brand-text font-weight-bold">e-JOTS</span>
  </a>
  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar Menu -->
    <nav class="mt-5 text-white">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <li class="nav-item">
          <a href="<?= base_url() ?>dashboard/" class="nav-link <?php if ($this->session->func == 'dash') { ?> active<?php } ?>">
            <i class="fa fa-tachometer-alt nav-icon"></i>
            <p>DASHBOARD</p>
          </a>
        </li>
        <?php if ($this->session->role != 1) { ?>
          <li class="nav-item">
            <a href="<?= base_url() ?>dailytimesheet/create" class="nav-link <?php if ($this->session->func == 'dailytimesheetcreate') { ?> active<?php } ?>">
              <!-- <i class="far fa-clipboard nav-icon"></i> -->
              <i class="fa fa-edit nav-icon"></i>
              <p>ENTRY DAILY TIMESHEET</p>
            </a>
          </li>
        <?php } ?>
        <li class="nav-item">
          <a href="<?= base_url() ?>dailytimesheet/review" class="nav-link <?php if ($this->session->func == 'dailytimesheetreview') { ?> active<?php } ?>">
            <i class="fa fa-copy nav-icon"></i>
            <p>REVIEW DAILY TIMESHEET</p>
          </a>
        </li>
        <li class="nav-item has-treeview<?php if ($this->session->tree == 'monthly') { ?> menu-open<?php } ?>">
          <a href="#" class="nav-link<?php if ($this->session->tree == 'monthly') { ?> active<?php } ?>">
            <i class="nav-icon fas fa-table"></i>
            <!-- <i class="nav-icon fas fa-chart-pie"></i> -->
            <p>
              MONTHLY
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?= site_url('monthly/employee') ?>" class="nav-link <?php if ($this->session->func == 'monthlyemployee') { ?> active<?php } ?>">
                <i class="">Emp</i>
                <p>EMPLOYEE</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= site_url('monthly/discipline') ?>" class="nav-link <?php if ($this->session->func == 'monthlydiscipline') { ?> active<?php } ?>">
                <i class="">Dis</i>
                <p>DISCIPLINE</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= site_url('monthly/department') ?>" class="nav-link <?php if ($this->session->func == 'monthlydepartment') { ?> active<?php } ?>">
                <i class="">Dep</i>
                <p>DEPARTMENT</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= site_url('monthly/perjob') ?>" class="nav-link <?php if ($this->session->func == 'monthlyperjob') { ?> active<?php } ?>">
                <i class="">Job</i>
                <p>PER JOB</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="<?= base_url() ?>total/" class="nav-link <?php if ($this->session->func == 'total_') { ?> active<?php } ?>">
            <i class="fas fa-table nav-icon"></i>
            <p>TOTAL TIMESHEET PERJOB</p>
          </a>
        </li>
        <li class="nav-item has-treeview<?php if ($this->session->tree == 'resume') { ?> menu-open<?php } ?>">
          <a href="#" class="nav-link<?php if ($this->session->tree == 'resume') { ?> active<?php } ?>">
            <i class="nav-icon fas fa-table"></i>
            <!-- <i class="nav-icon fas fa-chart-pie"></i> -->
            <p>
              RESUME
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?= site_url('resume/') ?>" class="nav-link <?php if ($this->session->func == 'resumes') { ?> active<?php } ?>">
                <i class="">TiS</i>
                <p>TIME SHEET</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= site_url('resume/perjob') ?>" class="nav-link <?php if ($this->session->func == 'resumetsperjob') { ?> active<?php } ?>">
                <i class="">Job</i>
                <p>TIME SHEET PERJOB</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item has-treeview<?php if ($this->session->tree == 'ranking') { ?> menu-open<?php } ?>">
          <a href="#" class="nav-link<?php if ($this->session->tree == 'ranking') { ?> active<?php } ?>">
            <i class="nav-icon fas fa-table"></i>
            <!-- <i class="nav-icon fas fa-chart-pie"></i> -->
            <p>
              OVERTIME RANKING
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?= site_url('ranking/employee') ?>" class="nav-link <?php if ($this->session->func == 'rankemployee') { ?> active<?php } ?>">
                <i class="">Emp</i>
                <p>EMPLOYEE</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= site_url('ranking/discipline') ?>" class="nav-link <?php if ($this->session->func == 'rankdiscipline') { ?> active<?php } ?>">
                <i class="">Dis</i>
                <p>DISCIPLINE</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item nav-header">
          <p><b><u>MASTER DATA</u></b></p>
        </li>
        <li class="nav-item has-treeview<?php if ($this->session->tree == 'master') { ?> menu-open<?php } ?>">
          <a href="#" class="nav-link<?php if ($this->session->tree == 'master') { ?> active<?php } ?>">
            <i class="nav-icon fas fa-archive"></i>
            <!-- <i class="nav-icon fas fa-chart-pie"></i> -->
            <p>
              MASTER
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?= base_url() ?>employees/" class="nav-link <?php if ($this->session->func == 'employees') { ?> active<?php } ?>">
                <i class="fa fa-user nav-icon"></i>
                <p>EMPLOYEES</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url() ?>departments/" class="nav-link <?php if ($this->session->func == 'departments') { ?> active<?php } ?>">
                <i class="fa fa-building nav-icon"></i>
                <p>DEPARTMENTS</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url() ?>disciplines/" class="nav-link <?php if ($this->session->func == 'disciplines') { ?> active<?php } ?>">
                <i class="fa fa-layer-group nav-icon"></i>
                <!-- <i class="fa fa-tachometer-alt nav-icon"></i> -->
                <p>DISCIPLINES</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url() ?>jobs/" class="nav-link <?php if ($this->session->func == 'jobs') { ?> active<?php } ?>">
                <i class="fa fa-tasks nav-icon"></i>
                <p>JOBS</p>
              </a>
            </li>
          </ul>
        </li>
      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside>