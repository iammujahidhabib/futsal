<!-- /.control-sidebar -->

<!-- Main Footer -->
<br>
<br>
<br>
<br>
<footer class="main-footer" style="margin-left: 0px !important;">
  <!-- To the right -->
  <div class="float-right d-none d-sm-inline">
    Anything you want
  </div>
  <!-- Default to the left -->
  <strong>Copyright &copy; <?=date("Y")?>
</footer>
</div>
<!-- ./wrapper -->
<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<?php $this->load->view('template/js'); ?>
<script>
  var timestamp = '<?= time(); ?>';

  function updateTime() {
    $('#time').html(Date(timestamp));
    timestamp++;
  }
  $(document).ready(function() {
    setInterval(updateTime, 1000);
    $('.example2').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
<!-- Bootstrap 4 -->

</body>

</html>