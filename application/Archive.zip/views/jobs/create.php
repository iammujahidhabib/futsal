<?php $this->load->view('template/header'); ?>
<style type="text/css">
	.gagal {
		color: red;
	}
</style>
<!-- Main content -->
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header row">
						<div class="col-sm-12 col-md-6">
							<h4 class="card-title">Create Job</h4>
						</div>
					</div>
					<div class="card-body">
						<form method="post" action="<?= site_url() ?>jobs/create/" enctype="multipart/form-data">
							<div class="form-group row">
								<label for="inp-job_number" class="col-sm-2 col-form-label">Job Number</label>
								<div class="col-sm-10">
									<input required type="text" class="form-control" name="job_number" id="inp-job_number" placeholder="Job Number">
								</div>
							</div>
							<div class="form-group row">
								<label for="inp-job_title" class="col-sm-2 col-form-label">Job Title</label>
								<div class="col-sm-10">
									<input required type="text" class="form-control" name="job_title" id="inp-job_title" placeholder="Job Title">
								</div>
							</div>
							<div class="form-group row">
								<label for="inp-submit" class="col-sm-2 col-form-label"></label>
								<div class="col-sm-10">
									<input type="submit" name="submit" class="btn btn-primary btn-block" value="Create">
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $this->load->view('template/footer'); ?>