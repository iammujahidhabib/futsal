<?php $this->load->view('template/header'); 
if (isset($_GET['date'])) {
    $full_date = $_GET['date'];
    $month = date('m', strtotime($_GET['date']));
    $month_name = date('F', strtotime($_GET['date']));
    $year = date('Y', strtotime($_GET['date']));
} else {
    $full_date = date('Y-m');
    $month = date('m');
    $month_name = date('F');
    $year = date('Y');
}
?>
<?php
if (isset($_GET['start']) && isset($_GET['end'])) {
    $start = $_GET['start'];
    $end = $_GET['end'];
} else {
    $start = date('Y-01-01');
    $end = date('Y-m-d');
}
$start    = (new DateTime($start))->modify('first day of this month');
$end      = (new DateTime($end))->modify('first day of next month');
$interval = DateInterval::createFromDateString('1 month');
$period   = new DatePeriod($start, $interval, $end);
$d_count = 0;
foreach ($period as $dt) {
    $d_count++;
}
$get_totals = 0;
foreach ($data as $key => $value) {
    $get_totals += $value['total_overtime'];
}
?>

<style>
    th {
        vertical-align: middle !important;
        text-align: center;
    }
</style>
<!-- Main content -->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header row">
                        <div class="col-sm-12 col-md-6">
                            <h4 class="card-title">RANGKING OF EMPLOYEE OVERTIME</h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="example2_wrapper" class="dataTables_wrapper dt-bootstrap4">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group row">
                                        <div class="col-sm-6">
                                            <label for="">Start</label>
                                            <input type="date" name="daterange" id="start_date" class="form-control" value="<?= $start->format('Y-m-d') ?>" />
                                        </div>
                                        <div class="col-sm-6">
                                            <label for="">End</label>
                                            <input type="date" name="daterange" id="end_date" class="form-control" value="<?= $end->format('Y-m-d') ?>" />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <button id="submit_filter" class="btn btn-primary btn-sm btn-block" style="margin: auto;">Filter</button>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <table id="example2" class="example2 table table-bordered table-hover dataTable dtr-inline" role="grid" aria-describedby="example2_info">
                                        <thead>
                                            <tr role="row">
                                                <th rowspan="2">No</th>
                                                <th rowspan="2">Badge</th>
                                                <th rowspan="2">Name</th>
                                                <th rowspan="2">Discipline</th>
                                                <th colspan="2">Overtime</th>
                                            </tr>
                                            <tr role="row">
                                                <th>Hour</th>
                                                <th>%</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $no = 1;
                                            foreach ($data as $key => $value) { ?>
                                                <tr>
                                                    <td><?= $no; ?></td>
                                                    <td><?= $value['badge']; ?></td>
                                                    <td><?= $value['name']; ?></td>
                                                    <td><?= $value['discipline_name']; ?></td>
                                                    <td><?= $value['total_overtime']; ?></td>
                                                    <td><?= ($get_totals > 0) ? round(($value['total_overtime'] / $get_totals) * 100) : 0; ?>%</td>
                                                </tr>
                                            <?php $no++;
                                            } ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="4">TOTAL</td>
                                                <td><?= $get_totals ?></td>
                                                <td><?= ($get_totals > 0) ? round(($get_totals / $get_totals) * 100) : 0; ?>%</td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function hapus(id) {
        var konfirmasi = confirm('Anda yakin akan menghapus?');
        if (konfirmasi == true) {
            window.location.href = '<?= base_url() ?>employees/delete/' + id;
        }
    }
    $("#submit_filter").click(function() {
        var _end_date = $("#end_date").val()
        var _start_date = $("#start_date").val()
        var _url = "<?= site_url('ranking/employee?') ?>start=" + _start_date + "&end=" + _end_date
        window.location.href = _url;
    });
</script>
<?php $this->load->view('template/footer'); ?>